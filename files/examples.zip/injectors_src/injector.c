#include <windows.h>
#include <stdio.h>

int main() {
    // Define your shellcode - MUST be x64.
    // unsigned char shellcode[] = {/* Shellcode here */};

    // Example calculator shellcode: msfvenom -p windows/x64/exec CMD=calc.exe -f c
    unsigned char shellcode[] = {
        //
    };

    // Allocate an RWX memory region, for allocation types etc. see the documentation - https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualalloc
    SIZE_T shellcodeSize = sizeof(shellcode);
    LPVOID addr = VirtualAlloc(NULL, shellcodeSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (addr == NULL) {
        printf("Failed to allocate RWX memory, exitting.\n");
        return -1;
    }

    // Copy the shellcode into the allocated memory
    memcpy(addr, shellcode, shellcodeSize);

    /************************************************************************/
    // Create a thread in the shellcode memory region to execute it
    // You must do this yourself
    HANDLE hThread = CreateThread(...);
    /************************************************************************/

    // Hang the injector by waiting for the thread, otherwise it will just exit
    WaitForSingleObject(hThread, 0xFFFFFFFF);
    return 0;
}
